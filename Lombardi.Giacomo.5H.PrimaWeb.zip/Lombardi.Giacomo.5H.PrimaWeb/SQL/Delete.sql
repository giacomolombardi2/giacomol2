DELETE FROM Prenotazioni
WHERE PrenotazioneId=14 OR PrenotazioneId=13;

SELECT * FROM Prenotazioni;