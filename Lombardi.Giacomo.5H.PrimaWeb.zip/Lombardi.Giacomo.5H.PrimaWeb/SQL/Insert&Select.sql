-- SQLite
INSERT INTO Prenotazioni (PrenotazioneId, Nome, Email)
VALUES ("Pino","Pino@insegno.it");

SELECT PrenotazioneId, Nome, Email
FROM Prenotazioni
WHERE Nome="giacomo";